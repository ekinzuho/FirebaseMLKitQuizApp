//
//  AllScores.swift
//  FirebaseMLKitQuizApp
//
//  Created by Ekin Zuhat Yaşar on 31.12.2023.
//

import Foundation

struct AllScores: Decodable {
    
    var scores: [Score]
    
}
