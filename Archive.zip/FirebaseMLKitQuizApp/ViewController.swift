//
//  ViewController.swift
//  FirebaseMLKitQuizApp
//
//  Created by Ekin Zuhat Yaşar on 30.12.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

