# FirebaseMLKitQuizApp
Firebase MLKit face angle controlled quiz game
